//LEDPatterns.c

#include "LEDPatterns.h"

void DelayedOnOffSuqeunce()
{
	TurnOffAllLEDs();
	for(int c=0; c<25; c++)
	{
		for(int iLED=0; iLED<20; iLED++)
		{	
			TurnOnLED(iLED);
			__delay_ms(1);
		}		
	}
	TurnOffAllLEDs();
	__delay_ms(250);
	
}

void SingleRotorCW()
{
	TurnOffAllLEDs();
	for(int iLED=0; iLED<10; iLED++)
	{
		for(int c=0; c<50; c++)
		{
			TurnOnLED(iLED);
			__delay_ms(1);
			TurnOnLED(iLED+10);
			__delay_ms(1);
		}
	}
}

void SingleRotorCCW()
{
	TurnOffAllLEDs();
	for(int iLED=9; iLED>=0; iLED--)
	{
		for(int c=0; c<50; c++)
		{
			TurnOnLED(iLED);
			__delay_ms(1);
			TurnOnLED(iLED+10);
			__delay_ms(1);
		}
	}
}

void SingleOddEven()
{
	TurnOffAllLEDs();
	for(int c=0; c<50; c++)
	{
		for(int iLED=0; iLED<20; iLED+=2)
		{
			TurnOnLED(iLED);
			__delay_ms(1);
		}
	}

	for(int c=0; c<50; c++)
	{
		for(int iLED=1; iLED<20; iLED+=2)
		{
			TurnOnLED(iLED);
			__delay_ms(1);
		}
	}
}

void QuartersFanCW()
{
	TurnOffAllLEDs();
	for(int i=0; i<20; i++)
	{
		for(int c=0; c<5; c++)
		{
			for(int q=0; q<4; q++)
			{
				int iLED = i + q;
				if(iLED >=19)
				{
					iLED = 19-(i+q);
				}
		
				TurnOnLED(iLED);
				__delay_ms(1);
			}
		}
	}
}

void WaterFall()
{
	TurnOffAllLEDs();
	for(int i=0; i<10; i++)
	{	
		for(int c=0; c<50; c++)
		{
			for(int j=0; j<i; j++)
			{
				int iLED = i+j;
				TurnOnLED(iLED);
				__delay_ms(1);
				TurnOnLED(19-iLED);
				__delay_ms(1);
			}
		}
	}
}

