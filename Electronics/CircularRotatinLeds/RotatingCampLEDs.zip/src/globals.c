//globals.c
#include "globals.h"

void TurnOffAllLEDs()
{
	LED0 = LED1 = LED2 = LED3 = LED4 = LED5 = LED6 = LED7 = 0;
	LEDCTL0 = LEDCTL1 = LEDCTL2 = 0;
}

void TurnOnLED(int iLED)
{
	TurnOffAllLEDs();

	switch(iLED)
	{
		case 0:
			LED0 = 1;
			LEDCTL0 = 1;
			break;

		case 1:
			LED1 = 1;
			LEDCTL0 = 1;
			break;

		case 2:
			LED2 = 1;
			LEDCTL0 = 1;
			break;

		case 3:
			LED3 = 1;
			LEDCTL0 = 1;
			break;

		case 4:
			LED4 = 1;
			LEDCTL0 = 1;
			break;

		case 5:
			LED5 = 1;
			LEDCTL0 = 1;
			break;

		case 6:
			LED6 = 1;
			LEDCTL0 = 1;
			break;

		case 7:
			LED7 = 1;
			LEDCTL0 = 1;
			break;

		case 8:
			LED0 = 1;
			LEDCTL1 = 1;
			break;

		case 9:
			LED1 = 1;
			LEDCTL1 = 1;
			break;

		case 10:
			LED2 = 1;
			LEDCTL1 = 1;
			break;

		case 11:
			LED3 = 1;
			LEDCTL1 = 1;
			break;

		case 12:
			LED4 = 1;
			LEDCTL1 = 1;
			break;

		case 13:
			LED5 = 1;
			LEDCTL1 = 1;
			break;

		case 14:
			LED6 = 1;
			LEDCTL1 = 1;
			break;

		case 15:
			LED7 = 1;
			LEDCTL1 = 1;
			break;

		case 16:
			LED0 = 1;
			LEDCTL2 = 1;
			break;

		case 17:
			LED1 = 1;
			LEDCTL2 = 1;
			break;

		case 18:
			LED2 = 1;
			LEDCTL2 = 1;
			break;

		case 19:
			LED3 = 1;
			LEDCTL2 = 1;
			break;

		default:
			break;

	}
}