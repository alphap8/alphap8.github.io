//main.c
#include "globals.h"
#include "LEDPatterns.h"

void main()
{
	INTCON = 0x0; //Disables all interrupts
	CMCON = 0x7; //Comparators off
	VRCON = 0x0; //Voltage References off
	T1CON = 0x0;

	TRISA = 0b00000000;
	TRISB = 0b00000000;

	while(1)
	{
		for(int c=0; c<5; c++)
			DelayedOnOffSuqeunce();

		for(int c=0; c<10; c++)
			SingleRotorCW();

		for(int c=0; c<10; c++)
			SingleRotorCCW();

		for(int c=0; c<10; c++)
			SingleOddEven();

		for(int c=0; c<10; c++)
			QuartersFanCW();

		for(int c=0; c<10; c++)
			WaterFall();
	}
}