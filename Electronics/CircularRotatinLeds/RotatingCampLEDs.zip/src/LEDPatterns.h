//LEDPatterns.h

#ifndef _LEDPATTERNS_H
#define _LEDPATTERNS_H

#include "globals.h"

void DelayedOnOffSuqeunce();
void SingleRotorCW();
void SingleRotorCCW();
void SingleOddEven();
void QuartersFanCW();
void WaterFall();

#endif //_LEDPATTERNS_H