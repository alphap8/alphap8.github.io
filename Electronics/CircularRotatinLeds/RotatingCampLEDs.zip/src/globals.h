//globals.h
#ifndef _GLOBALS_H
#define _GLOBALS_H

#include <htc.h>

#define _XTAL_FREQ 4000000

#define LED0 RA0
#define LED1 RA1
#define LED2 RA2
#define LED3 RA3
#define LED4 RB0
#define LED5 RB5
#define LED6 RA6
#define LED7 RA7

#define LED8 RA0
#define LED9 RA1
#define LED10 RA2
#define LED11 RA3
#define LED12 RB0
#define LED13 RB5
#define LED14 RA6
#define LED15 RA7

#define LED16 RA0
#define LED17 RA1
#define LED18 RA2
#define LED19 RA3

#define LEDCTL0 RB3
#define LEDCTL1 RB6
#define LEDCTL2 RB7

void TurnOnLED(int iLED);
void TurnOffAllLEDs();


#endif //_GLOBALS_H